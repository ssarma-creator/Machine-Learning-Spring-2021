#!/usr/bin/env python
# coding: utf-8

# In[51]:


import numpy as np
import os
import math
import pandas as pd
from sklearn.model_selection import train_test_split


# In[52]:


#Importing data
os.chdir("C:/Users/Joey/Desktop/Pima")
os.listdir()
data=pd.read_csv("pima-indians-diabetes.csv")
#Accuracy for 10 iterations
accuracyOfList_k1=[]
accuracyOfList_k5=[]
accuracyOfList_k11=[]


# In[217]:


data


# In[218]:



#Taking required features for training into a list
features=["Glucose concentration","Blood Pressure","Skin thickness","Outcome"]
#Creating a DataFrame with the list features
X_frame=data[features]
#Spliting the Datasets into 2 parts i.e Training Set and Test Set
X_train,X_test = train_test_split(X_frame, test_size=0.5)


# In[219]:


X_train


# In[220]:


#calculating Euclidean distance for two vectors
def distance(x,y):
    t=(x-y)**2
    s=np.sum(t,axis=0)
    d=np.sqrt(s)
    return d


# In[221]:


#Method to perform KNN
def knn(x,k,x_prev):
    #Making a copy of the data set to temporarily store the distance values
    x1=x_prev.copy()
    #t list stores the distance of the numpy array "x" to all the sample from the given dataset "x_prev"
    t=[]
    for i in range(x_prev.shape[0]):
        d=distance(x,x_prev.iloc[i,:].to_numpy().reshape(X_train.shape[1],1))
        t.append(d)
    #Adding new column as the distance to the "x1" DataFrame
    x1["distance"]=t
    #Sorts the DataFrame based upon the distance values 
    x2=x1.sort_values(by=['distance'])
    #sorted_k_indexes stores the K Nearest Neighbours to the test sample
    sort_k_indexes=[]
    for j in range(k):
        sort_k_indexes.append(x2.iloc[j,4])
    classA=0
    classB=0
    #calculating how many classA and ClassB outcomes were there in these K values
    for p in range(len(sort_k_indexes)):
        if(sort_k_indexes[p]==1):
            classB+=1
        else:
            classA+=1
    #if ClassB values is more than assign the test sample to ClassB(outcome 1) otherwise ClassA
    if(classA>classB):
        return 0
    else:
        return 1


# In[222]:


#Accuracy for K=1
predicted_res=[]
for k in range(X_test.shape[0]):
        #Changing the test sample from Pandas Series to numpy Array and reshaping it
        p=X_test.iloc[k,:].to_numpy().reshape(X_train.shape[1],1)
        #Calling the knn method and storing the return in a label
        label=knn(p,1,X_train)
        if(label==1):
            predicted_res.append(1)
        else:
            predicted_res.append(0)
XTest=X_test.copy()
    #adding a column to the test set DataFrame with the predicted values
XTest["predictedRes"]=predicted_res
correct=0
incorrect=0
for k in range(XTest.shape[0]):
        #If predicted values and actual outcome is same then incrementing the correct variable
        if(XTest.iloc[k,3]==XTest.iloc[k,4]):
            correct+=1
        else:
            incorrect+=1
print("Total no of correctly predicted values:" +str(correct))
accuracy_k1=correct/X_test.shape[0]
print("Accuracy: "+str(accuracy_k1))


# In[223]:


#Accuracy for K=5
predicted_res=[]
for k in range(X_test.shape[0]):
        #Changing the test sample from Pandas Series to numpy Array and reshaping it
        p=X_test.iloc[k,:].to_numpy().reshape(X_train.shape[1],1)
        #Calling the knn method and storing the return in a label
        label=knn(p,5,X_train)
        if(label==1):
            predicted_res.append(1)
        else:
            predicted_res.append(0)
XTest=X_test.copy()
    #adding a column to the test set DataFrame with Predicted values
XTest["predictedRes"]=predicted_res
correct=0
incorrect=0
for k in range(XTest.shape[0]):
        #If predicted values and actual outcome is same then increment the correct variable
        if(XTest.iloc[k,3]==XTest.iloc[k,4]):
            correct+=1
        else:
            incorrect+=1
print("Total no of correctly predicted values:" +str(correct))
accuracy_k5=correct/X_test.shape[0]
print("accuracy: "+str(accuracy_k5))


# In[224]:


#Accuracy for K=11
predicted_res=[]
for k in range(X_test.shape[0]):
        #Changing the test sample from Pandas Series to numpy Array and reshaping it
        p=X_test.iloc[k,:].to_numpy().reshape(X_train.shape[1],1)
        #Calling the knn method and storing the return in a label
        label=knn(p,11,X_train)
        if(label==1):
            predicted_res.append(1)
        else:
            predicted_res.append(0)
XTest=X_test.copy()
    #adding a column to the test set DataFrame with Predicted values
XTest["predictedRes"]=predicted_res
correct=0
incorrect=0
for k in range(XTest.shape[0]):
        #If predicted values and actual outcome is same then increment the correct variable
        if(XTest.iloc[k,3]==XTest.iloc[k,4]):
            correct+=1
        else:
            wrong+=1
print("Total no of correctly predicted values:" +str(correct))
accuracy_k11=correct/X_test.shape[0]
print("accuracy: "+str(accuracy_k11))


# In[225]:


accuracyOfList_k1.append(accuracy_k1)
accuracyOfList_k5.append(accuracy_k5)
accuracyOfList_k11.append(accuracy_k11)


# In[226]:


accuracyOfList_k1


# In[227]:


accuracyOfList_k5


# In[228]:


accuracyOfList_k11


# In[239]:


#mean accuracy
mean_k1=sum(accuracyOfList_k1)/len(accuracyOfList_k1)
mean_k5=sum(accuracyOfList_k5)/len(accuracyOfList_k5)
mean_k11=sum(accuracyOfList_k11)/len(accuracyOfList_k11)
print("Mean for K==1: "+str(mean_k1))
print("Mean for K==5: "+str(mean_k5))
print("Mean for K==11: "+str(mean_k11))


# In[240]:


q=0
for a in range(len(accuracyOfList_k1)):
   q+=(accuracyOfList_k1[a]-mean_k1)**2
z=q/(len(accuracyOfList_k1)-1)
std_deviation_k1=math.sqrt(z)


# In[241]:


print(std_deviation_k1)


# In[242]:


q=0
for a in range(len(accuracyOfList_k5)):
  q+=(accuracyOfList_k5[a]-mean_k5)**2
z=q/(len(accuracyOfList_k5)-1)
std_deviation_k5=math.sqrt(z)


# In[243]:


print(std_deviation_k5)


# In[244]:


q=0
for a in range(len(accuracyOfList_k11)):
    q+=(accuracyOfList_k1[a]-mean_k11)**2
z=q/(len(accuracyOfList_k11)-1)
std_deviation_k11=math.sqrt(z)


# In[245]:


print(std_deviation_k11)


# In[ ]:




