#!/usr/bin/env python
# coding: utf-8

# In[34]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


# In[35]:


def mean(x):
    x_mean=np.mean(x,axis=0)
    return x_mean


# In[36]:


class1=np.array([[-2,1],[-5,-4],[-3,1],[0,-3],[-8,-1]])
class2=np.array([[2,5],[1,0],[5,-1],[-1,-3],[6,1]])
class1


# In[37]:


mean1=np.mean(class1,axis=0)
mean2=np.mean(class2,axis=0)


# In[38]:


S1=(class1.shape[0]-1)*np.cov(class1.T)
S2=(class2.shape[0]-1)*np.cov(class2.T)


# In[39]:


S1


# In[40]:


S2


# In[41]:


S_W=S1+S2


# In[42]:


#within class scatter matrix
S_W


# In[43]:


np.linalg.inv(S_W)


# In[44]:


Optimal_direction=np.dot(np.linalg.inv(S_W),mean1-mean2)


# In[45]:


print("Optimal Line Direction: ")
print(Optimal_direction)


# In[46]:


t_class1=np.dot(class1,Optimal_direction)
t_class2=np.dot(class2,Optimal_direction)


# In[47]:


t_class1


# In[48]:


t_class2


# In[49]:


print("points correctly classified:")
for i in range(class1.shape[0]):
    if(t_class1[i]>0):
        print(class1[i])
for i in range(class2.shape[0]):
    if(t_class2[i]<0):
        print(class2[i])


# In[50]:


print("points incorrectly classified:")
for i in range(class1.shape[0]):
    if(t_class1[i]<0):
        print(class1[i])
for i in range(class2.shape[0]):
    if(t_class2[i]>0):
        print(class2[i])


# In[ ]:




