#!/usr/bin/env python
# coding: utf-8

# In[1787]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os
from sklearn.model_selection import train_test_split


# In[1788]:


#importing data
os.chdir("C:/Users/Joey/Desktop/Pima")
os.listdir()
data=pd.read_csv("pima-indians-diabetes.csv")
#Storing 10 runs
averageAccuracy=[]


# In[2022]:


data


# In[2023]:


#splitting the data
X_train,X_test=train_test_split(data,test_size=0.5)


# In[2024]:


class1=X_train[X_train["Outcome"]==0]
class2=X_train[X_train["Outcome"]==1]


# In[2025]:


def mean(X):
    X_mean=np.mean(X,axis=0)
    return X_mean


# In[2026]:


MeanClass1=mean(class1.iloc[:,:8])
MeanClass2=mean(class2.iloc[:,:8])
trMean=mean(X_train.iloc[:,:8])


# In[2027]:


MeanClass1=MeanClass1.to_numpy().reshape(MeanClass1.shape[0],1)
MeanClass2=MeanClass2.to_numpy().reshape(MeanClass1.shape[0],1)
trMean=trMean.to_numpy().reshape(trMean.shape[0],1)


# In[2028]:


S1=(class1.shape[0]-1)*np.dot((class1.iloc[:,:8]-MeanClass1.T).T,(class1.iloc[:,:8]-MeanClass1.T))
S2=(class2.shape[0]-1)*np.dot((class2.iloc[:,:8]-MeanClass2.T).T,(class2.iloc[:,:8]-MeanClass2.T))
Sw=S1+S2


# In[2029]:


Sw


# In[2030]:


trMean.shape


# In[2031]:


Sb1=(class1.shape[0]-1)*np.dot((trMean-MeanClass1.T),(trMean-MeanClass1.T))
Sb2=(class2.shape[0]-1)*np.dot((trMean-MeanClass2.T),(trMean-MeanClass2.T))
Sb=Sb1+Sb2


# In[2032]:


inv_Sw=np.linalg.inv(Sw)


# In[2033]:


MeanClass1.shape


# In[2034]:


optimal_direction=np.dot(inv_Sw,MeanClass1-MeanClass2)
optimal_direction


# In[2035]:


Class1_LDA=class1.iloc[:,:8]*optimal_direction.T
Class2_LDA=class2.iloc[:,:8]*optimal_direction.T


# In[2036]:


X_trainA=Class1_LDA
X_trainB=Class2_LDA


# In[2037]:


prior_probability_A=X_trainA.shape[0]/(X_trainA.shape[0]+X_trainB.shape[0])
prior_probability_B=X_trainB.shape[0]/(X_trainA.shape[0]+X_trainB.shape[0])


# In[2038]:


#function which takes "mean" and "covariance" as the parameters and returns the likelihood of the Feature Vector
def likelihood(x,mean,cov):
    #inverse of the covariance matrix
    inv=np.linalg.inv(cov)
    t1=1/(np.sqrt(((2*np.pi)**3)*np.linalg.det(cov)))
    t2=np.exp(-0.5*np.dot(np.dot((x-mean).T,inv),(x-mean)))
    t=t1*t2
    return t


# In[2039]:


#calculating the covariance matrix for both classes(A and B)
covarianceA=np.cov(X_trainA.iloc[:,:].T)
covarianceB=np.cov(X_trainB.iloc[:,:].T)


# In[2040]:


MeanVecA=np.mean(X_trainA,axis=0)
MeanVecB=np.mean(X_trainB,axis=0)


# In[2041]:


MeanVecA=MeanVecA.to_numpy().reshape(1,MeanVecA.shape[0])
MeanVecB=MeanVecB.to_numpy().reshape(1,MeanVecB.shape[0])


# In[2042]:


X_test


# In[2043]:


X_testA=X_test.iloc[:,:8]
def accuracy(X_test,Optimal_direction,MeanVecA,MeanVecB,covarianceA,covarianceB,prior_probability_A,prior_probability_B):
    a=X_test.iloc[:,:8]*Optimal_direction.T
    count=0
    for i in range(X_test.shape[0]):
        p=a.iloc[i,:].to_numpy().reshape(a.shape[1],1)
        posA=likelihood(p,MeanVecA.T,covarianceA)*prior_probability_A
        posB=likelihood(p,MeanVecB.T,covarianceB)*prior_probability_B
        if(posA<posB):
            if(X_test.iloc[i,8]==1):
                count+=1
        else:
            if(X_test.iloc[i,8]==0):
                count+=1
    classificationAccuracy=count/X_test.shape[0]
    return classificationAccuracy


# In[2044]:


avgAccuracy = accuracy(X_test,optimal_direction,MeanVecA,MeanVecB,covarianceA,covarianceB,prior_probability_A,prior_probability_B)


# In[2045]:


averageAccuracy.append(avgAccuracy)


# In[2046]:


averageAccuracy


# In[2048]:


print(np.mean(averageAccuracy))


# In[ ]:





# In[ ]:




