# -*- coding: utf-8 -*-
"""
Created on Tue Mar 16 16:39:15 2021

@author: Joey
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import math

def normal(mean,variance,no_of_samples):
    sigma = math.sqrt(variance)
    X=np.random.normal(mean,sigma,no_of_samples)
    X=X.reshape(no_of_samples,1)
    return X
mu=int(input("Enter the mean:"))
variance=int(input("Enter the variance:"))
no_of_samples=int(input("Enter the number of samples you want to generate:"))
X=normal(mu,variance,no_of_samples)
print(X)